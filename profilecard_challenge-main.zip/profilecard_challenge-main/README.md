This is a solution to the [Profile card component challenge on Frontend Mentor](https://www.frontendmentor.io/challenges/profile-card-component-cfArpWshJ). Frontend Mentor challenges help you improve your coding skills by building realistic projects. 

### The challenge

- Build out the project to the designs provided

### Screenshot

### Links

- Live Site URL: [Github URL](https://maurog15.github.io/profilecard_challenge/)
- Solution URL:[Frontendmentor solution](https://www.frontendmentor.io/solutions/responsive-profile-card-website-with-basic-html-and-css-Xk6vxVFVJp)

### Links
It was the first time making my own responsive web design, and i think i got a good result. Continue studying and learning!
